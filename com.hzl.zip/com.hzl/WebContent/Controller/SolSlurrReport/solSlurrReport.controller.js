sap.ui.define([
		"com/hzl/Controller/baseController"
	], function(baseController) {
	"use strict";

	return baseController.extend("com.hzl.Controller.SolSlurrReport.solSlurrReport", {

		onInit : function (evt) {
			
		}
	
	});	

});